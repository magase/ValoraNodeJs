module.exports = {
    database: {
        //Crear la conextion
            host: 'localhost',
            user: 'root',
            password: '',
            database: 'valora'
    }
}